---
name: Atelier Jurídico Editorial
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#45474c'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f74'
  primary: '#000102'
  on-primary: '#ffffff'
  primary-container: '#111c2e'
  on-primary-container: '#7a849b'
  inverse-primary: '#bcc7df'
  secondary: '#785835'
  on-secondary: '#ffffff'
  secondary-container: '#ffd2a6'
  on-secondary-container: '#795935'
  tertiary: '#000001'
  on-tertiary: '#ffffff'
  tertiary-container: '#131c2a'
  on-tertiary-container: '#7b8496'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fc'
  primary-fixed-dim: '#bcc7df'
  on-primary-fixed: '#111c2e'
  on-primary-fixed-variant: '#3c475b'
  secondary-fixed: '#ffdcbc'
  secondary-fixed-dim: '#eabf93'
  on-secondary-fixed: '#2c1700'
  on-secondary-fixed-variant: '#5e411f'
  tertiary-fixed: '#dae3f7'
  tertiary-fixed-dim: '#bec7da'
  on-tertiary-fixed: '#131c2a'
  on-tertiary-fixed-variant: '#3e4757'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 68px
    fontWeight: '400'
    lineHeight: 76px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 38px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  title-editorial:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.18em
  body-lead:
    fontFamily: Manrope
    fontSize: 19px
    fontWeight: '300'
    lineHeight: 32px
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.08em
  numeral-accent:
    fontFamily: Playfair Display
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.05em
spacing:
  space-hairline: 1px
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
  space-editorial: 8rem
  container-max: 1360px
  gutter-desktop: 2.5rem
  gutter-mobile: 1.25rem
---

## Brand & Style

This design system expresses a high-echelon, editorial architecture tailored for contemporary legal practice. Rejecting antiquated judicial clichés (gavels, balancing scales, marbled pillars, heavy drop-shadows), the identity approaches jurisprudence as rigorous craft and intellectual stewardship. 

The emotional posture is quiet, authoritative, and uncompromisingly refined. Layouts take direct cues from monograph publishing and high-fashion architectural journals: generous whitespace, razor-thin structural hairpins, asymmetrical editorial pacing, and deliberate typographic rhythm. Interactions are understated and deliberate—relying on hairline borders, subtle opacity shifts, and strict planar alignment rather than simulated physical elevation.

## Colors

The chromatic architecture is restrained, warm, and print-inspired:

- **Primary (`#111C2E`)**: Deep institutional navy, used for high-impact brand statements, primary CTA buttons, and stark contrasting surfaces.
- **Secondary / Accent (`#9A7650`)**: Muted architectural bronze, reserved exclusively for structural rules, case numbering, chapter markers, and exquisite detail trims. Never overused as a general fill.
- **Tertiary / Sub-neutral (`#0C1523`)**: Abyssal night navy, dedicated to deep structural anchors such as the primary footer and formal dark-mode editorial segments.
- **Editorial Text (`#222222`)**: Deep charcoal graphite for lead typography and major headings, ensuring reading softness superior to pure black.
- **Muted Editorial Text (`#6C6C6C`)**: Neutral mid-tone grey for citations, dates, subheadings, and secondary metadata.
- **Canvas Base (`#F7F5F0`)**: Warm off-white parchment foundation, providing tactile paper warmth across the primary viewport.
- **Surface Shift (`#EEEAE3`)**: Soft secondary beige for alternating content bands, inset dossiers, and analytical data sheets.
- **Purity Surface (`#FFFFFF`)**: Pure white, deployed surgically for active inputs, modal canvases, and sharp typographic relief.
- **Structural Hairlines**: Hairline division using `rgba(17, 28, 46, 0.12)` or `rgba(154, 118, 80, 0.35)` for bronze accents.

## Typography

The typographic hierarchy pairs the high-contrast elegance of **Playfair Display** with the neutral, rational clarity of **Manrope**.

- **Editorial Display & Headlines**: Set in Playfair Display with delicate serifs, tall ascenders, and tight tracking. Headings avoid bold weights to preserve a bookish, lithe dignity.
- **Eyebrows & Section Markers (`title-editorial`)**: Rendered in uppercase Manrope with expansive tracking (`0.18em`). Paired consistently with bronze indices (e.g., `01 / PRÁTICA CORPORATIVA`).
- **Body & Longform**: Set in Manrope light and regular weights with generous line height (`1.7x`), facilitating uninterrupted parsing of complex briefs and opinion pieces.
- **Numerals**: Key metric callouts and article dates prioritize Playfair Display figures for curated editorial authority.

## Layout & Spacing

The layout is built upon an architectural 12-column grid characterized by deliberate asymmetry and expansive margins.

- **Grid Architecture**: 12 columns with 40px gutters on desktop (`≥ 1024px`), 8 columns with 24px gutters on tablet (`768px - 1023px`), and 4 columns with 20px gutters on mobile (`< 768px`).
- **Editorial Asymmetry**: Featured dossiers, practice areas, and partner profiles frequently adopt offset column allocations (e.g., 5-column descriptor pinned against a 7-column analytical index), preventing formulaic card repetition.
- **Whitespace Discipline**: Vertical rhythm between sections utilizes `space-2xl` (64px) to `space-editorial` (128px), ensuring intellectual cadence and effortless visual deceleration.

## Elevation & Depth

This design system completely repudiates conventional blurred shadows, skeuomorphic drop-shadows, and floating cards. Elevation is planar, tectonic, and flat:

- **Surface Segmentation**: Depth is governed solely by tonal juxtaposition—shifting between `#F7F5F0` (base canvas) and `#EEEAE3` (secondary module backdrop).
- **Hairline Framing**: Structural separation uses strictly calibrated 1px rules (`rgba(17, 28, 46, 0.12)` or accent bronze `rgba(154, 118, 80, 0.35)`). Overlapping containers do not float; they dock cleanly along precise perimeter lines.
- **Modals & Overlays**: Lightbox dossiers and navigation curtains employ a stark `#111C2E` backdrop with 40% opacity blur (`backdrop-filter: blur(4px)`), presenting a crisp `#FFFFFF` or `#F7F5F0` architectural sheet anchored by sharp 1px border edges.

## Shapes

The geometry is uncompromisingly crisp: `roundedness: 0` (Sharp). 

Every component—buttons, inputs, dossiers, dialogue panes, and category badges—possesses zero border radius (0px). This rectilinear geometry mirrors architectural blueprints, legal codices, and luxury editorial formats. Round corners, pills, or playful geometries are strictly forbidden, reinforcing solemnity, permanence, and precision.

## Components

### Buttons
- **Primary**: Solid `#111C2E` background, `#F7F5F0` text, 0px radius, 14px uppercase Manrope typography with `0.1em` tracking. Padding: 16px vertical, 32px horizontal. Hover transition shifts background to `#0C1523` with a sharp 1px internal bronze outline (`#9A7650`).
- **Secondary / Editorial Outline**: Transparent background, 1px solid `#111C2E` (or `#9A7650`), text in matching tone. Hover fills the container smoothly with the line color while text reverses to `#FFFFFF` or `#F7F5F0`.
- **Text Link Action**: `#111C2E` text followed by a thin directional glyph (`→`), anchored by an underline positioned 4px beneath the baseline that transitions its origin horizontally on hover.

### Form Inputs & Textareas
- Seamless integration with the canvas: transparent or `#FFFFFF` fills paired with a 1px solid bottom border (`rgba(17, 28, 46, 0.25)`) rather than boxed perimeters. 
- On focus, the bottom border intensifies to 1px solid `#9A7650` (bronze) without outer glow or box-shadow halos.
- Floating label rendered in Manrope 11px uppercase (`#6C6C6C`).

### Cards & Case Dossiers
- Rejecting container cards with floating elevation. Content units are structured as tabular editorial dossiers bordered by 1px hairlines.
- Top border features a bronze index marker (`01`, `02`, `03`) alongside an uppercase category eyebrow.
- Hover states initiate a subtle canvas transition from `#F7F5F0` to `#EEEAE3` alongside an arrow glide interaction (`translate-x: 4px`).

### Lists & Case Studies
- Structured as continuous legal registers. Each row is delimited by a 1px `rgba(17, 28, 46, 0.12)` rule.
- Layout: 2-column tabular format (Year / Jurisdiction at left; Title, Summary, and Lead Partner at right).

### Checkboxes & Radio Elements
- Sharp 14px square boxes (0px border radius) with 1px solid `#111C2E`.
- Active state renders a crisp solid bronze (`#9A7650`) square insert leaving a 2px inner negative margin.

### Badges & Metas
- Flat rectangular geometry without fill: 1px border in `#9A7650` or `#111C2E`, 4px vertical by 10px horizontal padding, 10px Manrope uppercase text.